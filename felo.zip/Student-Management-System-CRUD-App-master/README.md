# Student-Management-System-CRUD-App
This is Simple student management system build in java and sqlite android application ,its application take all the operation like create , read, delete and update the student record.


## CRUD Sqlite App: 
<p float="left">
 <img src="https://github.com/deepakjaiswal2018/Student-Management-System-CRUD-App/blob/master/demo/preview1.jpg" width="260" height="450" />
<img src="https://github.com/deepakjaiswal2018/Student-Management-System-CRUD-App/blob/master/demo/preview2.jpg" width="260" height="450" />
<img src="https://github.com/deepakjaiswal2018/Student-Management-System-CRUD-App/blob/master/demo/preview3.jpg" width="260" height="450" />
</p>

<p float="left">
 <img src="https://github.com/deepakjaiswal2018/Student-Management-System-CRUD-App/blob/master/demo/preview4.jpg" width="260" height="450" />
<img src="https://github.com/deepakjaiswal2018/Student-Management-System-CRUD-App/blob/master/demo/preview5.jpg" width="260" height="450" />
<img src="https://github.com/deepakjaiswal2018/Student-Management-System-CRUD-App/blob/master/demo/preview6.jpg" width="260" height="450" />
</p>
